import React from 'react';
//import {Link} from 'react-router-dom';

function CheckOut(){
    return(
        <div className="container">
          <h1 >Checkout</h1>
          <p>Thank you for your order.</p>
        </div>
          
           
     
        )
}
export default CheckOut;