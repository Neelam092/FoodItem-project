import React from 'react';
//import {Link} from 'react-router-dom';
import FoodItems from './FoodItems';


function Menu(){
    return(
        <>
          <div className="menu">
            <FoodItems />
          </div>
        </>
        )
}
export default Menu;