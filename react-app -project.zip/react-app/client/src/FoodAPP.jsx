import React from 'react';
import  Image  from './assets/restaurant-2.svg';

function FoodAPP(){
    return(
        <div className="navbar">
            
            <h2><img src={Image} alt=""></img>food's rastaurant</h2>
        </div>
        )
}
export default FoodAPP;